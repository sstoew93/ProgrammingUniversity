TRUNCATE TABLE countries;
TRUNCATE TABLE attractions;
TRUNCATE TABLE personal_datas;
TRUNCATE TABLE visitors;